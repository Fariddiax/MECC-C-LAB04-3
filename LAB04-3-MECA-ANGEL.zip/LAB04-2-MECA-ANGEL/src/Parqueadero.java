import java.util.ArrayList;
import java.util.List;
import java.util.Stack;
import java.util.Scanner;

public class Parqueadero {

    private static int numVehiculo = 1;
    private static final List<Vehiculo> vehiculos = new ArrayList<>();
    private static final Stack<Vehiculo> motosBicicletas = new Stack<>();
    private static final Stack<Vehiculo> carros = new Stack<>();
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int opcion = 0;
        do {
            System.out.println("Bienvenido al parqueadero. Seleccione una opcion:");
            System.out.println("1. Ingreso de vehiculo");
            System.out.println("2. Visualizar tabla actualizada con la informacion ingresada e incluya el valor a pagar");
            System.out.println("3. Visualizar en una lista los vehiculos de 2 ruedas e incluir el valor a pagar en total");
            System.out.println("4. Visualizar en una lista los vehiculos de 4 ruedas e incluir el valor a pagar en total");
            System.out.println("5. Cantidad de vehiculos en parqueadero y valor total a pagar");
            System.out.println("6. Eliminar algun vehiculo");
            System.out.println("7. Salir");
            opcion = scanner.nextInt();
            scanner.nextLine(); // Consumir la lÃ­nea en blanco
            switch(opcion) {
                case 1:
                    ingresarVehiculo(scanner);
                    break;
                case 2:
                    visualizarTablaActualizada();
                    break;
                case 3:
                    visualizarListaVehiculos(motosBicicletas);
                    break;
                case 4:
                    visualizarListaVehiculos(carros);
                    break;
                case 5:
                    cantidadVehiculosParqueadero();
                    break;
                case 6:
                    eliminarVehiculo(scanner);
                    break;
                case 7:
                    System.out.println("Gracias por utilizar el parqueadero.");
                    break;
                default:
                    System.out.println("Opcion invalida. Por favor seleccione una Opcion valida.");
            }
        } while(opcion != 7);
    }
    
    private static void ingresarVehiculo(Scanner scanner) {
        System.out.println("Ingrese la placa del vehiculo:");
        String placa = scanner.nextLine();
        System.out.println("Ingrese el tipo de vehiculo (1 - bicicleta, 2 - ciclomotor, 3 - motocicleta, 4 - carro):");
        int tipo = scanner.nextInt();
        scanner.nextLine(); // Consumir la lÃ­nea en blanco
        System.out.println("Ingrese la hora de ingreso (formato 24 horas por favor):");
        int hora = scanner.nextInt();
        scanner.nextLine(); // Consumir la lÃ­nea en blanco
        
        Vehiculo vehiculo = new Vehiculo(numVehiculo, placa, tipo, hora);
        vehiculos.add(vehiculo);
        numVehiculo++;
        
        switch(tipo) {
            case 1:
            case 2:
                motosBicicletas.push(vehiculo);
                break;
            case 3:
                motosBicicletas.push(vehiculo);
                break;
            case 4:
                carros.push(vehiculo);
                break;
            default:
                System.out.println("Tipo de vehiculo invalido. No se pudo agregar a la lista de vehiculos.");
    }
    
    System.out.println("El vehiculo ha sido ingresado exitosamente al parqueadero.");
}

private static void visualizarTablaActualizada() {
    System.out.printf("%-15s%-15s%-15s%-15s%-15s\n", "NÂ° VehÃ­culo", "Placa", "Tipo", "Hora de ingreso", "Valor a pagar");
    for(Vehiculo vehiculo : vehiculos) {
        System.out.printf("%-15d%-15s%-15s%-15d%-15d\n", vehiculo.getNumVehiculo(), vehiculo.getPlaca(), 
                vehiculo.getTipoVehiculo(), vehiculo.getHoraIngreso(), vehiculo.getValorAPagar());
    }
}

private static void visualizarListaVehiculos(Stack<Vehiculo> lista) {
    int valorTotalAPagar = 0;
    System.out.printf("%-15s%-15s%-15s\n", "No. Vehiculo", "Placa", "Valor a pagar");
    for(Vehiculo vehiculo : lista) {
        System.out.printf("%-15d%-15s%-15d\n", vehiculo.getNumVehiculo(), vehiculo.getPlaca(), vehiculo.getValorAPagar());
        valorTotalAPagar += vehiculo.getValorAPagar();
    }
    System.out.printf("Valor total a pagar: %d\n", valorTotalAPagar);
}

private static void cantidadVehiculosParqueadero() {
    int numVehiculos = vehiculos.size();
    int valorTotalAPagar = 0;
    for(Vehiculo vehiculo : vehiculos) {
        valorTotalAPagar += vehiculo.getValorAPagar();
    }
    System.out.printf("Hay %d vehiculos en el parqueadero.\n", numVehiculos);
    System.out.printf("Valor total a pagar: %d\n", valorTotalAPagar);
}

private static void eliminarVehiculo(Scanner scanner) {
    System.out.println("Ingrese el No de vehiculo que desea eliminar:");
    int numVehiculo = scanner.nextInt();
    scanner.nextLine(); // Consumir la linea en blanco
    boolean eliminado = false;
    for(int i = 0; i < vehiculos.size(); i++) {
        if(vehiculos.get(i).getNumVehiculo() == numVehiculo) {
            Vehiculo vehiculo = vehiculos.remove(i);
            eliminado = true;
            switch(vehiculo.getTipo()) {
                case 1:
                case 2:
                    motosBicicletas.remove(vehiculo);
                    break;
                case 3:
                    motosBicicletas.remove(vehiculo);
                    break;
                case 4:
                    carros.remove(vehiculo);
                    break;
                default:
                    break;
            }
            System.out.printf("El vehÃ­culo con nÃºmero %d y placa %s ha sido eliminado exitosamente del parqueadero.\n", 
                    vehiculo.getNumVehiculo(), vehiculo.getPlaca());
            break;
        }
    }
    if(!eliminado) {
        System.out.println("El nÃºmero de vehÃ­culo ingresado no corresponde a ningÃºn vehÃ­culo en el parqueadero.");
    }
}

private static class Vehiculo {

        private final int numVehiculo;
        private final String placa;
        private final int tipo;
        private final int horaIngreso;
    
    public Vehiculo(int numVehiculo, String placa, int tipo, int horaIngreso) {
        this.numVehiculo = numVehiculo;
this.placa = placa;
this.tipo = tipo;
this.horaIngreso = horaIngreso;
calcularValorAPagar();
}
public int getNumVehiculo() {
        return numVehiculo;
    }
    
    public String getPlaca() {
        return placa;
    }
    
    public int getTipo() {
        return tipo;
    }
    
    public String getTipoVehiculo() {
        switch(tipo) {
            case 1:
                return "Bicicleta";
            case 2:
                return "Ciclomotor";
            case 3:
                return "Motocicleta";
            case 4:
                return "Carro";
            default:
                return "";
        }
    }
    
    public int getHoraIngreso() {
        return horaIngreso;
    }
    
    public int getValorAPagar() {
            int valorAPagar = 0;
        return valorAPagar;
    }
    
    private void calcularValorAPagar() {
        switch(tipo) {
            case 1:
            case 2:
                break;

            case 3:
                break;
            case 4:
                break;
            default:
                break;
        }
    }
    }
}